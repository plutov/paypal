/* @flow */

import * as INTERFACE from './interface'; // eslint-disable-line import/no-namespace

export * from './interface';
export default INTERFACE;
