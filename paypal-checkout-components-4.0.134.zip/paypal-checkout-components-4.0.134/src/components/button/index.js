/* @flow */

import './hacks'; // eslint-disable-line import/no-unassigned-import

export * from './component';
