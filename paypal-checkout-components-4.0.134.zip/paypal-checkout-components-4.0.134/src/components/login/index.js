/* @flow */

import './prerender'; // eslint-disable-line import/no-unassigned-import

export * from './component';
