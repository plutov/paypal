/* @flow */

export const CHECKOUT_OVERLAY_COLOR = {
    BLACK: 'black',
    WHITE: 'white'
};
